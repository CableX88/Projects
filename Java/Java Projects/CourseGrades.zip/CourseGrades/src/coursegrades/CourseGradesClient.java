/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursegrades;

/**
 *
 * @author DavidX2X
 */
public class CourseGradesClient {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CourseGrades gs1 = new CourseGrades("Bill","A");
        CourseGrades gs2 = new CourseGrades("Ted","B");
         System.out.println(gs1.getName());
        //s1.setSsn("78123");
        System.out.println(gs1.getGrade());
        
        
        System.out.println(gs2.ToString());
        
        if( gs1.Equals(gs2))
        {
            System.out.println(" true ");
        }
        else{
            System.out.println("false");
        }
        
        gs2.setName(gs1.getName());
        gs2.setGrade(gs1.getGrade());
        
     if( gs1.Equals(gs2))
        {
            System.out.println(" true ");
        }
        else{
            System.out.println("false");
        }
    }
    
}
